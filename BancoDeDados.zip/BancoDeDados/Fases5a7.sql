insert into fase (id_historia,id_fase,numero,descricao) values (1,null,5,"Foi oferecido a Yolanda a cidade de MONTEVIDÉU e RAQUIRA, com diferentes propostas de recompensa."),
(1,null,6,"Parabéns você escolheu o melhor destino.."), (1,null,7,"Ops, a casa caiu, a polícia estava a espera. Game Over");

insert into opcoes (id_opcoes,id_fase,opcao,destino) values (null,4,"Continuar",5), (null,5,"URUGUAI Montevidéu",6), (null,5,"BOGOTÁ Raquira",7);